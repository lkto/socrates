<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Iniciar Sesión</title>
    
        <!-- Plugin scripts -->
    <script src="plantilla/vendors/bundle.js"></script>
    <!-- App scripts -->
    <script src="plantilla/assets/js/app.js"></script>
    <script src="js/heaven/rollups/aes.js"></script>
    <script type="text/javascript" src="js/heaven/efectos.js"></script>

    <!-- Favicon -->
    <link rel="shortcut icon" href="plantilla/assets/media/image/favicon.png"/>
    <!-- Plugin styles -->
    <link rel="stylesheet" href="plantilla/vendors/bundle.css" type="text/css">
    <!-- App styles -->
    <link rel="stylesheet" href="plantilla/assets/css/app.min.css" type="text/css">


    <script type="text/javascript" >
      const menu = "<?php echo MENU ?>";
      const web_root = "<?php echo WEB_ROOT ?>";
      const page_root = "<?php echo PAGE_ROOT ?>";
        const TOKEN = "<?php echo TOKEN ?>";
        const hash = CryptoJS.MD5(TOKEN+"/()0-(**fg@A").toString();
console.log(hash);
    </script>


</head>
<body class="form-membership" style="background: url(img/fondo_login.jpg);background-size: cover;padding: 0px" >

<!-- begin::preloader-->
<div class="preloader">
    <div class="preloader-icon"></div>
</div>
<!-- end::preloader -->

<div class="form-wrapper" style="color: white;background-color: #0000005e !important;">
    
    <!-- logo -->
    <div id="logo">
        <img class="logo" src="img/logo2.png" alt="image">
        <img class="logo-dark" src="img/logo2.png" alt="image">
    </div>
    <!-- ./ logo -->
    <br>
    <h5>Iniciar Sesión</h5>

    <!-- form -->
    <form id="formulario"  autocomplete="off">         
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Ingrese Usuario" required autofocus autocomplete="off">
        </div>
        <div class="form-group">
            <input type="password" class="form-control" placeholder="Ingrese Contraseña" required autocomplete="off">
        </div>
         <button class="btn btn-primary btn-block">Ingresar</button>
        <hr>
         <div class="form-group d-flex justify-content-between">
            <a href="plantilla/recover-password.html">Reset password</a>
        </div>
    </form>
    <!-- ./ form -->

</div>


</body>
</html>
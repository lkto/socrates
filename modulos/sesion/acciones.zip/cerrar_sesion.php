<?php
session_destroy();
header("location: " . WEB_ROOT);
?>